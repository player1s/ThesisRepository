## Psychomotor Vigilance Task
This a free Psychomotor vigilance test created in PsychoPy for the tutorial
[https://www.marsja.se/psychomotor-vigilance-task-psychopy-pvt](https://www.marsja.se/psychomotor-vigilance-task-psychopy-pvt).

You are free to use and download the PVT for use in your research and student work. However, make sure you give credit to the blog post.

For example, here is an APA citation:

Marsja, E (2022, August 30). Psychomotor Vigilance Task (PVT) in PsychoPy. Marsja.se. https://www.marsja.se/psychomotor-vigilance-task-psychopy-pvt
